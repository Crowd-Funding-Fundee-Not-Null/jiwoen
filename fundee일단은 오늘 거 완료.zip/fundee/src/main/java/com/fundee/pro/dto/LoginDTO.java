package com.fundee.pro.dto;

import lombok.Data;

@Data
public class LoginDTO {
    private String id;
    private String password;
    private String passwordCheck; // ������(DB�÷�X)
    private String nickname;
    private String name;
    private String email;
    private String phone;
    private String address;
    private Integer role;
    private Integer join_date;
    
}
